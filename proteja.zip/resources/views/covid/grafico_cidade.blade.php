<!DOCTYPE html>
<html lang="pt">

<head>
  <title>Fianto - Transformando Vidas</title>

  <link rel="shortcut icon" href="{{asset('img/icone.png')}}" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

  <!-- Icomoon -->
  <link rel="stylesheet" type="text/css" href="{{asset('css/icomoon.css')}}">

  <!-- Font-Awesome -->
  <link rel="stylesheet" type="text/css" href="{{asset('css/font-awesome.css')}}">

  <!-- Slider -->
  <link rel="stylesheet" type="text/css" href="{{asset('css/swiper.min.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('css/rev-settings.css')}}">

  <!-- Animate.css -->
  <link rel="stylesheet" href="{{asset('css/animate.css')}}">

  <!-- Color Switcher -->
  <link rel="stylesheet" type="text/css" href="{{asset('css/switcher.css')}}">

  <!-- Owl Carousel  -->
  <link rel="stylesheet" href="{{asset('css/owl.carousel.css')}}">

  <!-- Bootstrap CSS-->
  <link rel="stylesheet" type="text/css" href="{{asset('/css/bootstrap.min.css')}}">
  <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"> -->

  <!-- Main Styles -->
  <link rel="stylesheet" type="text/css" href="{{asset('css/default.css')}}">
  <link rel="stylesheet" type="text/css" href="{{asset('css/styles-5.css')}}" id="colors">

  <!-- Fonts Google -->
  <link href="https://fonts.googleapis.com/css?family=Fira+Sans:100,200,300,400,500,600,700,800,900" rel="stylesheet">
  <link href="{{asset('css/simple-sidebar.css')}}" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Heebo:100,300,400,500,700,800,900&display=swap" rel="stylesheet">
  <script src="{{asset('js/mascara_telefone.js')}}"></script>
    <style>
    

    </style>
    @if(Request::input('cadastro') > 0)
    <script>
      alert("Suas informações foram recebidas com sucesso.\nAgradecemos a sua colaboração. ")
      window.location.href = '/painel'
    </script>
    @endif
    @isset($status)
      @if($status == "1")
        <?php
          echo "<script>alert('Informações atualizadas com sucesso!');window.location.href='/painel'</script>";
        ?>
      @else
        <?php
          echo "<script>alert('Erro na atualização\nVerifique suas informações!');window.location.href='/atualizar'</script>";
        ?>
      @endif
    @endisset
    @isset($dependentes)
      @if($dependentes == "0")
        <?php
          echo "<script>alert('Informações de dependentes atualizadas com sucesso!');window.location.href='/painel'</script>";
        ?>
      @else
        <?php
          echo "<script>alert('Erro na atualização de dependentes\nVerifique suas informações!');window.location.href='/atualizar'</script>";
        ?>
      @endif
    @endisset
</head>

<body>
<div style='width: 100vw;height: 100vh'>
<canvas id="myChart" style=""></canvas>

</div>


















<!-- <div class="container-fluid" style="margin-left: -15px">
  <div class="row" style="padding-bottom: 100px">
    <div class="col-3" style="">
    <div class="border-right" id="sidebar-wrapper">
      <div style="background-color: rgba(255,255,255,.5);padding: 5px">
        <img src="{{asset('img/Fianto_horizontal_positiva.png')}}" alt="" class="img-fluid">
      </div>
      <p style="color: gold;font-size: 20px;font-weight: 600;font-family: Heebo;margin-top: 15px;margin-bottom: 20px" align="center">Sistema Proteja</p>

      <div class="sidebar-heading" style="background-color: transparent;color: white" align="center">Dados do usuário</div>
      <hr>
      <ul>
        <li style="color:white;font-size: 14px"><div class="row"><div class="col-3">Nome: </div><div class="col-9">{{Request::session()->get('nome')}}</div></div></li>
        <li style="color:white;font-size: 14px"><div class="row"><div class="col-3">Email: </div><div class="col-9">{{Request::session()->get('email')}}</div></div></li>
        <li style="margin-top: 5px"><a href="{{route('logout')}}" class="btn btn-sm btn-danger" style="font-size: 12px">Sair</a></li>
      </ul>
      
      <div class="sidebar-heading mt-30" style="background-color: transparent;color: white" align="center">Menu</div>
      
      <div class="list-group list-group-flush">
        <a href="{{route('painel')}}" class="list-group-item list-group-item-action" style="color:white;background-color:#148b7e;font-size: 14px">Painel</a>
        <a href="{{route('relatorio')}}" class="list-group-item list-group-item-action" style="color:white;background-color:#148b7e;font-size: 14px">Voluntários na sua cidade</a>
        <a href="{{route('evolucao')}}" class="list-group-item list-group-item-action" style="color:white;background-color:#148b7e;font-size: 14px">Evolução do vírus em tempo real no Brasil</a>
      </div>

      <p style="font-size: 10px;color: white;position: absolute;bottom: 0;left:calc(50% - 40px);">versão beta 1.0</p>

    </div>

    </div>
    <div class="col-9">  
      <div class="row" style="height: 50vh">
        <div class="col-6">
          <p style="font-size: 15px;font-family: Heebo;text-align:center;margin-top: 20px;margin-bottom: 20px">Visão geral de voluntários no Brasil</p>
          <div id="map" style="height: 100%"></div>
        </div>
        <div class="col-6">
          <p style="font-size: 15px;font-family: Heebo;text-align:center;margin-top: 20px;margin-bottom: 20px">Acompanhe em tempo real a evolução do vírus</p>
          <iframe src="https://visao.ibict.br/#/visao?chart=1&grupCategory=16" style="margin-bottom: 100px;height: 100%;width: 100%;margin-left:auto;margin-right: auto;display: block"></iframe>
        </div>
      </div>
      <div class="row" style="height: 50vh;margin-top: 70px">
        <div class="col-6">
          <p style="font-size: 15px;font-family: Heebo;text-align:center;margin-top: 20px;margin-bottom: 20px">Visão geral de residências que precisam de auxílio no Brasil</p>
          <div id="columnchart_material" style="height: 100%;width: 100%"></div>
        </div>
        <div class="col-6">
          <p style="font-size: 15px;font-family: Heebo;text-align:center;margin-top: 20px;margin-bottom: 20px">Acompanhe em tempo real a evolução do vírus</p>
        </div>
      </div>
    </div>
      
  </div>
  


  </div> -->









  <!-- Jquery -->
  <script src="{{asset('js/jquery.min.js')}}"></script>

  <!--Popper JS-->
  <script src="{{asset('js/popper.min.js')}}"></script>

  <!-- Bootstrap JS-->
  <script src="{{asset('js/bootstrap.min.js')}}"></script>

  <!-- Owl Carousel-->
  <script src="{{asset('js/owl.carousel.js')}}"></script>

  <!-- Navbar JS -->
  <script src="{{asset('js/navigation.js')}}"></script>
  <script src="{{asset('js/navigation.fixed.js')}}"></script>

  <!-- Wow JS -->
  <script src="{{asset('js/wow.min.js')}}"></script>

  <!-- Countup -->
  <script src="{{asset('js/jquery.counterup.min.js')}}"></script>
  <script src="{{asset('js/waypoints.min.js')}}"></script>

  <!-- Tabs -->
  <script src="{{asset('js/tabs.min.js')}}"></script>

  <!-- Yotube Video Player -->
  <script src="{{asset('js/jquery.mb.YTPlayer.min.js')}}"></script>

  <!-- Swiper Slider -->
  <script src="{{asset('js/swiper.min.js')}}"></script>

  <!-- Isotop -->
  <script src="{{asset('js/isotope.pkgd.min.js')}}"></script>

  <!-- Switcher JS -->
  <script src="{{asset('js/switcher.js')}}"></script>

  <!-- Modernizr -->
  <script src="{{asset('js/modernizr.js')}}"></script>

  <!-- Chart JS -->
  <script src="{{asset('js/Chart.bundle.js')}}"></script>
  <script src="{{asset('js/utils.js')}}"></script>

  <!-- Revolution Slider -->
  <script src="{{asset('js/revolution/jquery.themepunch.tools.min.js')}}"></script>
  <script src="{{asset('js/revolution/jquery.themepunch.revolution.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.actions.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.carousel.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.kenburn.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.layeranimation.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.migration-2.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.parallax.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.navigation.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.slideanims.min.js')}}"></script>
  <script src="{{asset('js/revolution/revolution.extension.video.min.js')}}"></script>
  <!-- Chart JS -->
  <script src="{{asset('js/Chart.bundle.js')}}"></script>
  <script src="{{asset('js/utils.js')}}"></script>

  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <!-- Main JS -->
  <script src="{{asset('js/main.js')}}"></script>

<script src="https://www.google.com/jsapi"></script>


  <!--TRADUÇÃO -->
  <!-- <script src="{{asset('js/locales.js')}}"></script>

    <script type="text/javascript">
        $(document).ready(function () {
          var pt = "pt-br";
          var es = "es";
          var en = "en";
            $('#pt').click(function (){
              $(document).translate(pt);
              sessionStorage.setItem('linguagem' , 'pt-br');
            });
            $('#es').click(function (){
              $(document).translate(es);
              sessionStorage.setItem('linguagem' , 'es');
            });
            $('#en').click(function (){
              $(document).translate(en);
              sessionStorage.setItem('linguagem' , 'en');
            });
            if(!sessionStorage.linguagem){
              sessionStorage.setItem('linguagem' , 'pt-br');
              $(document).translate(sessionStorage.getItem("linguagem"))
            }else{
              $(document).translate(sessionStorage.getItem("linguagem"))
            }
        });
    </script> -->
    <!-- script do mapa  -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
  <!-- <script src="{{asset('js/util/mapa.js')}}"></script> -->
  <script src="https://unpkg.com/@google/markerclustererplus@4.0.1/dist/markerclustererplus.min.js"></script>
    <!-- Main JS -->
    <script src="{{asset('js/main.js')}}"></script>
  <script type="text/javascript">

var ctx = document.getElementById('myChart').getContext('2d');

      // gera os dados 
      var label = []
      var assitencia = []
      $.getJSON('/grafico-cidade-dados', obj => {
        console.log(obj)
        obj.forEach(element => {
            label.push([element.assistencia])
            assitencia.push(element.num)
          
        });
      });
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: label,
        datasets: [{
          label: "<--Clique no ícone ao lado duas vezes para obter os números",
          backgroundColor: '#148b7e',
          data: assitencia,
          
        }]

    },
    // Configuration options go here
    options:  {
      scales: {
          xAxes: [{
              stacked: false
          }],
          yAxes: [{
              stacked: true
          }]
      }
  }
});

     

   
 
  </script>

</body>

</html>