<?php

    print_r($_POST['cpf_risco']);