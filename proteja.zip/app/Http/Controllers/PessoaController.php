<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class PessoaController extends Controller
{
    // vai cadastrar uma pessoa como usurario, o primeiro cadastro
    function cadastro_completo(Request $request)
    {
        $request->validate([
            'nome' => 'required',
            'cpf' => 'required',
            'email' => 'required',
            'senha' => 'required'
        ], [
            'required' => 'O campo :attribute é obrigatório',
        ]);

        // verifico sem existe o cpf
        $result = DB::select("SELECT COUNT(cpf) as num FROM usuarios WHERE cpf = '$request->cpf' or email = '$request->email'");
        if ($result[0]->num < 1) {

            // cadastra o usuario sem a senha
            try {
                $idUsuario = DB::table('usuarios')->insertGetId($request->except('_token', 'senha', 'confirmacao'));
                if (!empty($idUsuario)) {

                    // cadastra a senha o usuario e finaliza o cadastro
                    try {
                        DB::update("UPDATE usuarios SET senha = '" . md5($request->confirmacao) . "' WHERE id = $idUsuario");

                        // cria uma sessão para o usuario 
                        $request->session()->put('idUsuario', $idUsuario);
                        $request->session()->put('nome', $request->nome);
                        $request->session()->put('email', $request->email);

                        // redireciona para o controller de confirmação de cadastro por e-mail
                        return redirect(route('email', [
                            'nome' => $request->nome,
                            'cpf' => $request->cpf,
                            'email' => $request->email,
                            'senha' => $request->senha,
                            'id' => $idUsuario
                        ]));
                    } catch (\Throwable $th) {
                        // se de erro no cadsatro irá apagar a conta do usuario
                        DB::delete("DELETE usuarios WHERE id = $idUsuario");
                        return redirect(route('erro'));
                    }
                }
            } catch (\Throwable $th) {
                // se de erro no cadsatro irá apagar a conta do usuario
                DB::delete("DELETE usuarios WHERE id = $idUsuario");
                return redirect(route('erro'));
            }
        } else {
            return redirect(route('login.page', ['cpf' => true]));
        }
    }

    // cadastrar endereco
    function cadastro_endereco(Request $request)
    {
        // $request->validate([
        //     'nome' => 'required',
        // ]);

        try {

            // atualiza a data de nascimento do usuario 
            DB::update("UPDATE usuarios SET data_nascimento = '$request->data',
            telefone = '$request->telefone' WHERE id = $request->cod");

            // cadastra o endereço 
            $idEndereco = DB::table('endereco')
            ->insertGetId($request->except('_token', 'cod', 'nome', 'cpf', 'data', 'telefone', 'pertense_grupo_risco', 'numero_pessoas', 'grupo_risco', 'faixa_etaria', 'assistência', 'nome_risco', 'cpf_risco'));

            if ($idEndereco > 0) {
                // cadastra o relacionamento de endereco
                $resultfinal = DB::table('endereco_usuario')->insert([
                    'id_endereco' => $idEndereco,
                    'id_usuario' => $request->cod,
                ]);

                if ($resultfinal){

                    // armazena a cidade do usuario 
                    $request->session()->put('localidade', $request->localidade);
                    $request->session()->put('idEndereco', $idEndereco);

                    return redirect(route('pergunta', ['success' => '1']));
                }
            }
        } catch (\Throwable $th) {
            return redirect(route('erro'));
            // return $th->getMessage();
            //throw $th;
        }
    }

    function pergunta_cadastro(Request $request)
    {
        try {
            if($request->pergunta_2 == "" || $request->pergunta_2 == "negativo"){
            // atualiza o sexo do usuario
            DB::update("UPDATE usuarios SET TESTADO = '$request->pergunta_1', RESULTADO_TESTE = '', DATA_TESTE = '', sexo = '$request->pergunta_3' WHERE id = " . $request->session()->get('idUsuario'));
            }else{
            // atualiza o sexo do usuario
            DB::update("UPDATE usuarios SET TESTADO = '$request->pergunta_1', RESULTADO_TESTE = '$request->pergunta_2', DATA_TESTE = '$request->data_exame', sexo = '$request->pergunta_3' WHERE id = " . $request->session()->get('idUsuario'));
            }
            

            // cadastra os grupos de risco da familia do usuario
            if (!empty($request->pergunta_4)) {
                foreach ($request->pergunta_4 as $value) {
                    DB::table('tipo_risco')->insert([
                        'grupo_risco' => "$value",
                        'id_endereco' => $request->session()->get('idEndereco'),
                    ]);
                }
            }

            return redirect(route('pergunta3'));
        } catch (\Throwable $th) {
            return redirect(route('erro'));
        }
    }

    function atualizar_pergunta_cadastro(Request $request){
        
            

            
    }

    function assistencia(Request $request)
    {
        // return response()->json($request->except('_token'));
        try {
            // atualiza a resposta do usuario se ele é um vonlutario
            $updateUsuario = DB::update("
                UPDATE usuarios SET 
                volutario = '$request->voluntario',
                isolamento = '$request->pergunta_6',
                num_pessoas_isolamento = '$request->pergunta_7',
                opniao_isolamento = '$request->opniao',
                grau_satisfacao = '$request->pergunta_10'
                WHERE id = " . $request->session()->get('idUsuario'));

            // cadastra a necessidade do usuario
            if (!empty($request->pergunta_9)) {
                foreach ($request->pergunta_9 as $value) {
                    $assistencia = DB::table('assistencia')->insert([
                        'assistencia' => $value,                     
                        'id_endereco' => $request->session()->get('idEndereco'),
                    ]);
                }
            }

            if($updateUsuario){
                return redirect(route('painel', ['cadastro' => true]));
            }else{
                return back()->with('error' , true);
            }

        } catch (\Throwable $th) {
            return redirect(route('erro', ['erro' => $th->getMessage()]));
            // return $th->getMessage();
        }
    }

    function membro_familiar(Request $request)
    {
                
                // cadastro cada membro da fmailia no grupo de risco 
        if(isset($request->cpf_risco[0])){
            try {
                        // cadastro cada membro da fmailia no grupo de risco     

                for($i = 0; $i < count($request->nome_risco); $i++){
                    $variavel = "pergunta_5".$i;
                    if($i > 0){
                        if($request->nome_risco[$i] == "" || $request->cpf_risco[$i] == "" || $request->$variavel[0] == ""){
                            return redirect(route('pergunta3'));
                        }else{
                        $membros_familia_add = DB::table('membros_familia')
                        ->insert([
                            'nome' => $request->nome_risco[$i],
                            'cpf' => $request->cpf_risco[$i],
                            'faixa_etaria' => $request->$variavel[0],
                            'id_endereco' => Session::get('idEndereco')
                        ]);
                    }
                        
                        
                    }else{
                        $membros_familia = DB::table('membros_familia')
                        ->insert([
                            'nome' => $request->nome_risco[0],
                            'cpf' => $request->cpf_risco[0],
                            'faixa_etaria' => $request->pergunta_5[0],
                            'id_endereco' => Session::get('idEndereco')
                        ]);
                    }
                }
                if($membros_familia && $membros_familia_add){
                    return redirect(route('pergunta3'));
                }else{
                    return back()->with('error' , true);
                }
            } catch (\Throwable $th) {
                return redirect(route('erro'));
            }
        } else {
            return redirect(route('pergunta3'));
        }
                
                
                // return redirect(route('pergunta3'));
            
    }

    function edicao_dependente(Request $request)
    {
                
                // cadastro cada membro da fmailia no grupo de risco 
        if(isset($request->cpf_risco[0])){
            try {
                        // cadastro cada membro da fmailia no grupo de risco     
                        $endereco_usuario = DB::table('endereco_usuario')
                        ->where('id_usuario', Session::get('idUsuario'))
                        ->get();
                        $endereco_id = $endereco_usuario[0]->id_endereco;
                        for($i = 0; $i < count($request->nome_risco); $i++){

                            $delete = DB::table('membros_familia')
                            ->where('id_endereco', $endereco_id)
                            ->delete();
                        }
                for($i = 0; $i < count($request->nome_risco); $i++){
                    $variavel = "pergunta_5".$i;
                    if($i > 0){
                        if($request->nome_risco[$i] == "" || $request->cpf_risco[$i] == "" || $request->$variavel[0] == ""){
                            return redirect(route('painel', ['error_dependentes', "0"]));
                        }else{
                            $membros_familia = DB::table('membros_familia')
                            ->update("UPDATE membros_familia SET
                                nome = '$request->nome_risco[0]',
                                cpf = '$request->cpf_risco[0]',
                                faixa_etaria = '$request->pergunta_5[0]',
                                WHERE id_endereco = '$endereco_id'"
                            );
                        }
                        
                        
                    }else{
                        $membros_familia = DB::table('membros_familia')
                        ->update("UPDATE membros_familia SET
                            nome = '$request->nome_risco[0]',
                            cpf = '$request->cpf_risco[0]',
                            faixa_etaria = '$request->pergunta_5[0]',
                            WHERE id_endereco = '$endereco_id'"
                        );
                    }
                }
                if($membros_familia){
                    return redirect(route('painel', ['error_dependentes', "0"]));
                }else{
                    return redirect(route('painel', ['error_dependentes', "1"]));
                }
            } catch (\Throwable $th) {
                return redirect(route('painel', ['error_dependentes', "1"]));
            }
        } else {
            return redirect(route('painel', ['error_dependentes', "0"]));
        }
                
                
                // return redirect(route('pergunta3'));
            
    }


    function verifica_cpf(Request $request){
        $cpf = DB::table('usuarios')
        ->where("cpf", $request->cpf)
        ->get();

        if(count($cpf) > 0){
            return "sim";
        }else{
            $cpf_membros_familia = DB::table('membros_familia')
            ->where("cpf", $request->cpf)
            ->get();
            if(count($cpf_membros_familia) > 0){
                return "sim";
            }else{
                return "nao";
            }
        }
    }

    public function atualizar_usuario(Request $request){
        $id_usuario = Session::get('idUsuario');
        
        try{
        $usuario = DB::update("UPDATE usuarios SET
            email = '$request->email',
            data_nascimento = '$request->data',
            telefone = '$request->telefone',
            TESTADO = '$request->pergunta_1',
            RESULTADO_TESTE = '$request->pergunta_2',
            DATA_TESTE = '$request->data_exame',
            sexo = '$request->pergunta_3',
            isolamento = '$request->pergunta_6',
            num_pessoas_isolamento = '$request->pergunta_7',
            opniao_isolamento = '$request->opniao',
            grau_satisfacao = '$request->pergunta_10',
            volutario = '$request->voluntario'
            WHERE id =  $id_usuario
        ");

        $endereco_usuario = DB::table('endereco_usuario')
        ->where('id_usuario', Session::get('idUsuario'))
        ->get();

        $endereco_usuario_request = $endereco_usuario[0]->id_endereco;

        
            $endereco = DB::update("UPDATE endereco set
                cep = '$request->cep',
                logradouro = '$request->logradouro',
                uf = '$request->uf',
                localidade = '$request->localidade',
                bairro = '$request->bairro',
                numero = '$request->numero'
                WHERE id = $endereco_usuario_request
            ");
            $endereco_usuario = DB::table('endereco_usuario')
            ->where('id_usuario', Session::get('idUsuario'))
            ->get();

            $endereco = $endereco_usuario[0]->id_endereco;
            // cadastra os grupos de risco da familia do usuario
            if (!empty($request->pergunta_4)) {
                foreach ($request->pergunta_4 as $value) {
                    DB::table('tipo_risco')
                    ->where('id_endereco' , $endereco)
                    ->delete();
                    
                }
                foreach ($request->pergunta_4 as $value) {
                    DB::table('tipo_risco')->insert([
                        'grupo_risco' => "$value",
                        'id_endereco' => $request->session()->get('idEndereco'),
                    ]);
                }
            }else{
                DB::table('tipo_risco')
                    ->where('id_endereco' , $endereco)
                    ->delete();
            }

            if (!empty($request->pergunta_9)) {
                foreach ($request->pergunta_9 as $value) {
                    DB::table('assistencia')
                    ->where('id_endereco' , $endereco)
                    ->delete();
                }
                foreach ($request->pergunta_9 as $value) {
                    $assistencia = DB::table('assistencia')->insert([
                        'assistencia' => $value,                     
                        'id_endereco' => $request->session()->get('idEndereco')
                    ]);
                }
            }
            
            $request->session()->put('email', $request->email);
            // $request->session()->put('nome', $request->nome);
            $request->session()->put('localidade', $request->localidade);

            return redirect()->route('painel', ['error'=> '0']);
        }catch(\Throwable $th){
            return redirect()->route('painel', ['error'=> '1']);
        }
        
            


    }

    function alterar_senha(Request $request){
        $idUsuario = Session::get('idUsuario');
        $senhaa = md5($request->senha_nova);
        $senha_antiga = DB::table("usuarios")
        ->where('id', $idUsuario)
        ->get();
        if($senha_antiga[0]->senha === md5($request->senha_antiga)){
            $senha = DB::update("UPDATE usuarios SET
                senha = '$senhaa'
                WHERE id = '$idUsuario'
            ");
            return redirect()->route('alterar_senha', ['success'=> '1']);
        }else{
            return redirect()->route('alterar_senha', ['success'=> '0']);
        }
        
        
    }


}

